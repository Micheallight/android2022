package com.michaellight.exchangeratesv1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.View
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.michaellight.exchangeratesv1.databinding.ActivityMainBinding
import com.michaellight.exchangeratesv1.databinding.ItemRateBinding
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.*
import java.io.IOException
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

	private lateinit var binding: ActivityMainBinding

	private lateinit var rateAdapter: RateAdapter

	private val client = OkHttpClient()

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		binding = ActivityMainBinding.inflate(layoutInflater)
		setContentView(R.layout.activity_main)
		setupRecyclerView()

//		run("https://www.nbrb.by/api/exrates/rates?periodicity=0")

		lifecycleScope.launchWhenCreated {
			binding.rvRatesList.isVisible = true
			tvNoNet.visibility = View.VISIBLE
			val response = try {
				RetrofitInstance.api.getRates()
//				Log.d("TAG8", RetrofitInstance.api.getRates().toString())
			} catch (e: IOException) {
				Log.e("ERROR", e.message.toString())
				return@launchWhenCreated
			}
			if(response.isSuccessful && response.body() != null) {
				tvNoNet.visibility = View.GONE
				rateAdapter.rates = response.body()!!
//				Log.d("TAG3", rateAdapter.rates.toString())
//				Log.d("TAG9", response.body().toString())
			}
//			binding.rvRatesList.
		}
	}
//	fun run(url: String) {
//		val request = Request.Builder()
//			.url(url)
//			.build()
//
//		client.newCall(request).enqueue(object : Callback {
//			override fun onFailure(call: Call, e: IOException) {}
//			override fun onResponse(call: Call, response: Response) = println(response.body?.string())
//		})
//	}

	private fun setupRecyclerView() = binding.rvRatesList.apply {
		rateAdapter = RateAdapter()
		Log.d("TAG4", RateAdapter().rates.toString())
		adapter = rateAdapter
		layoutManager = LinearLayoutManager(this@MainActivity)

	}

	override fun onCreateOptionsMenu(menu: Menu?): Boolean {
		menuInflater.inflate(R.menu.menu_main, menu)
		return super.onCreateOptionsMenu(menu)
	}
}