package lt.timofey.navdemon

data class Person (
    val name:String,
    val sname: String,
    val age: Int
    )