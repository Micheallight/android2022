package lt.timofey.navdemon

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class NavigationViewModel : ViewModel() {
    var person: Person? = null
    val livePerson: MutableLiveData<Person> = MutableLiveData(Person("Qwerty","Test",404))
}