package com.example.myexchange

data class Exchange(
    val rates: List<Rate>
)