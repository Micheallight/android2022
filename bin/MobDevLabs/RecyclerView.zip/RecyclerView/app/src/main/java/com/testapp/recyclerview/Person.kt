package com.testapp.recyclerview

data class Person (
    val name: String,
    val secondName: String,
    var age: Int,
    val photoId: Int
    )