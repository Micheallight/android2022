package com.testapp.project

class Const {
    companion object {
        const val LOG_TAG = "LogTag"
    }
}