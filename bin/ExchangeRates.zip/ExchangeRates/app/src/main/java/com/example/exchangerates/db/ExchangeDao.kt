package com.example.exchangerates.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy.IGNORE
import androidx.room.Query
import com.example.exchangerates.Exchange
import java.io.Serializable

@Dao
interface ExchangeDao: Serializable {
    @Query("SELECT * FROM exchanges")
    fun getAll(): List<Exchange>

    @Query("SELECT * FROM exchanges WHERE name LIKE (:city)")
    fun getByCity(city: String): List<Exchange>

    @Query("DELETE FROM exchanges")
    fun deleteAll()

    @Insert(onConflict = IGNORE)
    fun saveAll(exchanges: List<Exchange>)
}