package com.michaellight.notepadprojectv2.db

class ListItem {
	var id = 0
	var title = ""
	var date = ""
	var text = ""
}