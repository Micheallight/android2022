package com.michaellight.exchangeratesv1

import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.AsyncListDiffer
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.michaellight.exchangeratesv1.databinding.ItemRateBinding

class RateAdapter : RecyclerView.Adapter<RateAdapter.RateViewHolder>() {
	inner class RateViewHolder(val binding: ItemRateBinding) : RecyclerView.ViewHolder(binding.root)

	private val diffCallback = object : DiffUtil.ItemCallback<Rate>() {
		override fun areItemsTheSame(oldItem: Rate, newItem: Rate): Boolean {
			Log.d("TAG2", "oldItem.Cur_ID::: " + oldItem.Cur_ID.toString())
			return oldItem.Cur_ID == newItem.Cur_ID
		}

		override fun areContentsTheSame(oldItem: Rate, newItem: Rate): Boolean {
			Log.d("TAG2", "oldItem.Cur_ID::: " + oldItem.Cur_ID.toString())
			return oldItem.Cur_ID == newItem.Cur_ID
		}
	}

	private val differ = AsyncListDiffer(this, diffCallback)
	var rates: List<Rate>
	get() = differ.currentList
	set(value) {
//		Log.d("TAG6", value.toString())
		differ.submitList(value)
		Log.d("TAG7", differ.currentList.toString())
		Log.d("TAG7", rates.toString())
	}

	override fun getItemCount(): Int {
		Log.d("TAG2", "rates: " + rates.toString())
		return rates.size
	}

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RateViewHolder {
		Log.d("TAG5", parent.toString())
		Log.d("TAG5", "test")
		return RateViewHolder(ItemRateBinding.inflate(
			LayoutInflater.from(parent.context),
			parent,
			false
		))
	}

	override fun onBindViewHolder(holder: RateViewHolder, position: Int) {
		Log.d("TAG5", rates.toString())
		Log.d("TAG5", "test")
		holder.binding.apply {
			val rate = rates[position]
//			Log.d("TAG2", rate.toString())

			tvTitle.text = rate.Cur_Abbreviation
			tvPrice.text = rate.Cur_OfficialRate.toString()
		}
	}
}