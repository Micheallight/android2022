package com.michaellight.exchangeratesv1

import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.view.isVisible
import androidx.core.widget.EdgeEffectCompat.getDistance
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.michaellight.exchangeratesv1.databinding.ActivityMainBinding
import com.michaellight.exchangeratesv1.databinding.ItemRateBinding
import kotlinx.android.synthetic.main.activity_main.*
import okhttp3.*
import java.io.IOException
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import java.security.AccessController

class MainActivity : AppCompatActivity() {

	var curId: Int = 0
	var context: Context = this@MainActivity

	private lateinit var binding: ActivityMainBinding

	private lateinit var rateAdapter: RateAdapter

	private val client = OkHttpClient()

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)
		binding = ActivityMainBinding.inflate(layoutInflater)
		context = this@MainActivity
		setupRecyclerView()

//		run("https://www.nbrb.by/api/exrates/rates?periodicity=0")

		lifecycleScope.launchWhenCreated {
			binding.rvRatesList.isVisible = true
			tvNoNet.visibility = View.VISIBLE
			val response = try {
				RetrofitInstance.api.getRates()
//				Log.d("TAG8", RetrofitInstance.api.getRates().toString())
			} catch (e: IOException) {
				Log.e("ERROR", e.message.toString())
				return@launchWhenCreated
			}
			if(response.isSuccessful && response.body() != null) {
				tvNoNet.visibility = View.GONE
				rateAdapter.rates = response.body()!!

//				AlertDialog.Builder(context)
////					.setCustomTitle(textView)
////					.setMessage("Цена: ${products[position].price} руб.\nРейтинг: ${products[position].rating}")
//					.setMessage(rate.Cur_Name)
//					.setPositiveButton(android.R.string.ok, null)
//					.show()

//				RateAdapter().onBindViewHolder(ViewHolder(binding.root) as RateAdapter.RateViewHolder, 0)

//				Log.d("TAG3", rateAdapter.rates.toString())

//				Log.d("TAG9", response.body().toString())
//				Log.d("TAG9", rateAdapter.rates.toString())
			}
//			binding.rvRatesList.
		}
//		rvRatesList.adapter = rateAdapter
	}
//	fun run(url: String) {
//		val request = Request.Builder()
//			.url(url)
//			.build()
//
//		client.newCall(request).enqueue(object : Callback {
//			override fun onFailure(call: Call, e: IOException) {}
//			override fun onResponse(call: Call, response: Response) = println(response.body?.string())
//		})
//	}


	fun onClickItem(curID: Int) {
		Log.d("TAG11", curID.toString())

		Toast.makeText(context, "Empty db", Toast.LENGTH_SHORT).show()
//		AlertDialog.Builder(this)
////					.setCustomTitle(textView)
////					.setMessage("Цена: ${products[position].price} руб.\nРейтинг: ${products[position].rating}")
//			.setMessage(curID.toString())
//			.setPositiveButton(android.R.string.ok, null)
//			.show()
	}

//	fun onClickItem(): ItemTouchHelper {
////		AlertDialog.Builder()
////			.setMessage(rates[position].toString())
////			.setPositiveButton(android.R.string.ok, null)
////			.show()
//
//		return ItemTouchHelper(object: ItemTouchHelper
//		.SimpleCallback(0, ItemTouchHelper.) {
//			override fun onMove(
//				recyclerView: RecyclerView,
//				viewHolder: RecyclerView.ViewHolder,
//				target: RecyclerView.ViewHolder
//			): Boolean {
//				return false
//			}
//
//			override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
//				notepadAdapter.deleteItem(viewHolder.adapterPosition, notepadDBManager)
//			}
//		})
//
//		Log.d("TAG11", this.toString())
//	}

	private fun setupRecyclerView() = binding.rvRatesList.apply {
		rateAdapter = RateAdapter()
		rvRatesList.adapter = rateAdapter
		layoutManager = LinearLayoutManager(this@MainActivity)
	}

	override fun onCreateOptionsMenu(menu: Menu?): Boolean {
		menuInflater.inflate(R.menu.menu_main, menu)
		return super.onCreateOptionsMenu(menu)
	}
}