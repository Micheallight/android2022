package com.michaellight.notepadprojectv2.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.provider.BaseColumns
import android.util.Log
import java.util.ArrayList

class NotepadDBManager(val context: Context) {
	val notepadDBHelper = NotepadDBHelper(context)
	var db: SQLiteDatabase? = null

	fun openDB() {
		db = notepadDBHelper.writableDatabase
	}

	fun insertToDB(title: String, date: String, content: String) {
		val values = ContentValues().apply {
			put(NotepadDBNameClass.COLUMN_NAME_TITLE, title)
			put(NotepadDBNameClass.COLUMN_NAME_DATE, date)
			put(NotepadDBNameClass.COLUMN_NAME_TEXT, content)
		}
		db?.insert(NotepadDBNameClass.TABLE_NAME, null, values)
	}

	fun deleteFromDB(id: String) {
//		val selection = BaseColumns._ID + "=$id"

//		var sqlRequestDelete = "DELETE FROM " + NotepadDBNameClass.TABLE_NAME + " WHERE " +	BaseColumns._ID + " = " + id + ";"

//		Log.d("TAG1", id)
//		Log.d("TAG1", BaseColumns._ID + "=" + id)
//		Log.d("TAG1", NotepadDBNameClass.TABLE_NAME)

//		Log.d("TAG1", sqlRequestDelete)

//		Log.d("TAG1", id)
		db?.delete(NotepadDBNameClass.TABLE_NAME, BaseColumns._ID + "=" + id, null)

//		db?.execSQL(sqlRequestDelete)
	}

	fun readDBData() : ArrayList<ListItem> {
		val dataList = ArrayList<ListItem>()
		val cursor = db?.query(
			NotepadDBNameClass.TABLE_NAME,
			null,
			null,
			null,
			null,
			null,
			null
		)

		while (cursor?.moveToNext()!!) {
			val dataID = cursor?.getInt(cursor.getColumnIndexOrThrow(BaseColumns._ID))
			val dataTitle = cursor?.getString(cursor.getColumnIndexOrThrow(NotepadDBNameClass.COLUMN_NAME_TITLE))
			val dataDate = cursor?.getString(cursor.getColumnIndexOrThrow(NotepadDBNameClass.COLUMN_NAME_DATE))
			val dataText = cursor?.getString(cursor.getColumnIndexOrThrow(NotepadDBNameClass.COLUMN_NAME_TEXT))

			var item = ListItem()

			item.id = dataID
			item.title = dataTitle
			item.date = dataDate
			item.text = dataText

			dataList.add(item)
		}

		cursor.close()
		return dataList
	}

	fun closeDB() {
		notepadDBHelper.close()
	}
}