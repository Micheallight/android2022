package com.michaellight.mycalculatorv2

import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.view.marginLeft
import androidx.core.view.setMargins
import org.w3c.dom.Text

class MainActivity : AppCompatActivity() {
	val buttonTextsVertical = arrayOf<Array<String>>(
		arrayOf<String>("C", "⌫", "+/-", "÷"),
		arrayOf<String>("7", "8", "9", "×"),
		arrayOf<String>("4", "5", "6", "-"),
		arrayOf<String>("1", "2", "3", "+"),
		arrayOf<String>("0", "00", ".", "=")
	)

	val buttonTextsHorizontal = arrayOf<Array<String>>(
		arrayOf<String>("7", "8", "9", "÷", "C", "⌫"),
		arrayOf<String>("4", "5", "6", "×", "(", ")"),
		arrayOf<String>("1", "2", "3", "-", "^", "√"),
		arrayOf<String>("0", "00", ".", "+", "", "=")
	)

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)

		val btnTableVertical : LinearLayout = findViewById<LinearLayout>(R.id.clickTableVertical)
		val btnTableHorizontal : LinearLayout = findViewById<LinearLayout>(R.id.clickTableHorizontal)

		val calculatorTextVertical : TextView = findViewById<TextView>(R.id.mainFieldVertical)
//		val calculatorTextHorizontal : TextView = findViewById<TextView>(R.id.mainFieldHorizontal)


//		btnTableVertical.setWeightSum(0.25f)

//		var buttonsVertical = Array<Array<TextView>>()

		val rowsVertical = Array(5, { LinearLayout(this) })
		val buttonsVertical = Array(5, { Array(4, { TextView(this) }) })

		val rowsHorizontal = Array(4, { LinearLayout(this) })
		val buttonsHorizontal = Array(4, { Array(6, { TextView(this) }) })

		for (i in 0..4) {
//			rowsVertical[0].layoutParams = ConstraintLayout(ConstraintLayout.LayoutParams.MATCH_PARENT, ConstraintLayout.LayoutParams.MATCH_PARENT)
//			buttonsVertical += Array<TextView>(4) {}

			rowsVertical[i].layoutParams = LinearLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, 0, 1.0f)
//			rowsVertical[i].setWeightSum(0.25f)
			for (j in 0..3) {
				buttonsVertical[i][j].layoutParams =
					LinearLayout.LayoutParams(0, ConstraintLayout.LayoutParams.MATCH_PARENT, 1.0f)
				buttonsVertical[i][j].setTextAppearance(this, R.style.buttonsVerticaltyle)
				buttonsVertical[i][j].text = buttonTextsVertical[i][j]
				if (buttonsVertical[i][j].text.equals("=")) {
					buttonsVertical[i][j].setBackgroundColor(Color.parseColor("#113355"))
				} else {
					buttonsVertical[i][j].setBackgroundColor(Color.parseColor("#000000"))
				}
//				buttonsVertical[i][j].layoutParams.setMargins(1, 1, 1, 1) // = LinearLayout.LayoutParams.

				val param = buttonsVertical[i][j].layoutParams as ViewGroup.MarginLayoutParams
				param.setMargins(5,0,5,5)

				buttonsVertical[i][j].layoutParams = param
				buttonsVertical[i][j].textAlignment = View.TEXT_ALIGNMENT_CENTER
				buttonsVertical[i][j].setGravity(Gravity.CENTER_VERTICAL)
				buttonsVertical[i][j].setTextSize(30.0f)

				when(buttonsVertical[i][j].text.toString()) {
					in "0".."9" ->
						buttonsVertical[i][j].setOnClickListener {
							if (calculatorTextVertical.text.toString() == "0") {
								if (buttonsVertical[i][j].text.toString() != "00") {
									calculatorTextVertical.text = buttonsVertical[i][j].text.toString()
								}
							} else {
								calculatorTextVertical.text = calculatorTextVertical.text.toString() + buttonsVertical[i][j].text.toString()
							}
						}
					"C" ->
						buttonsVertical[i][j].setOnClickListener {
							calculatorTextVertical.text = "0"
						}
					"⌫" ->
						buttonsVertical[i][j].setOnClickListener {
							if (calculatorTextVertical.text.toString() != "0") {
								calculatorTextVertical.text = calculatorTextVertical.text.dropLast(1)
							}
						}
				}
				rowsVertical[i].addView(buttonsVertical[i][j])
			}
			btnTableVertical.addView(rowsVertical[i])
		}


		for (i in 0..3) {
			rowsHorizontal[i].layoutParams = LinearLayout.LayoutParams(ConstraintLayout.LayoutParams.MATCH_PARENT, 0, 1.0f)
			for (j in 0..5) {
				buttonsHorizontal[i][j].layoutParams =
					LinearLayout.LayoutParams(0, ConstraintLayout.LayoutParams.MATCH_PARENT, 1.0f)
				buttonsHorizontal[i][j].setTextAppearance(this, R.style.buttonsVerticaltyle)
				buttonsHorizontal[i][j].text = buttonTextsHorizontal    [i][j]
				if (buttonsHorizontal[i][j].text.equals("=")) {
					buttonsHorizontal[i][j].setBackgroundColor(Color.parseColor("#113355"))
				} else {
					buttonsHorizontal[i][j].setBackgroundColor(Color.parseColor("#000000"))
				}
//				buttonsVertical[i][j].layoutParams.setMargins(1, 1, 1, 1) // = LinearLayout.LayoutParams.

				val param = buttonsHorizontal[i][j].layoutParams as ViewGroup.MarginLayoutParams
				param.setMargins(5,0,5,5)

				buttonsHorizontal[i][j].layoutParams = param
				buttonsHorizontal[i][j].textAlignment = View.TEXT_ALIGNMENT_CENTER
				buttonsHorizontal[i][j].setGravity(Gravity.CENTER_VERTICAL)
				buttonsHorizontal[i][j].setTextSize(30.0f)

//				when(buttonsVertical[i][j].text.toString()) {
//					in "0".."9" ->
//						buttonsVertical[i][j].setOnClickListener {
//							if (calculatorTextVertical.text.toString() == "0") {
//								if (buttonsVertical[i][j].text.toString() != "00") {
//									calculatorTextVertical.text = buttonsVertical[i][j].text.toString()
//								}
//							} else {
//								calculatorTextVertical.text = calculatorTextVertical.text.toString() + buttonsVertical[i][j].text.toString()
//							}
//						}
//					"C" ->
//						buttonsVertical[i][j].setOnClickListener {
//							calculatorTextVertical.text = "0"
//						}
//					"⌫" ->
//						buttonsVertical[i][j].setOnClickListener {
//							if (calculatorTextVertical.text.toString() != "0") {
//								calculatorTextVertical.text = calculatorTextVertical.text.dropLast(1)
//							}
//						}
//				}
				rowsHorizontal[i].addView(buttonsHorizontal[i][j])
			}
			btnTableHorizontal.addView(rowsHorizontal[i])
		}
	}
}

//var btnTableVertical : LinearLayout = findViewById<LinearLayout>(R.id.clickTable)
//
//var newBtn = arrayOf<Button>(Button(this), Button(this), Button(this)) // Button(this)
//newBtn[0].layoutParams =
//ConstraintLayout.LayoutParams(100, 100)
//newBtn[0].text = "0"
//newBtn[1].layoutParams =
//ConstraintLayout.LayoutParams(100, 100)
//newBtn[1].text = "0"
//newBtn[2].layoutParams =
//ConstraintLayout.LayoutParams(100, 100)
//newBtn[2].text = "0"
//
//btnTableVertical.addView(newBtn[0])
//btnTableVertical.addView(newBtn[1])
//btnTableVertical.addView(newBtn[2])