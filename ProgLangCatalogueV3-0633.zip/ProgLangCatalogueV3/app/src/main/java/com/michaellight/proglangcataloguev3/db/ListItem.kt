package com.michaellight.proglangcataloguev3.db

class ListItem {
	var id = 0
	var title = ""
	var date = ""
	var text = ""
}