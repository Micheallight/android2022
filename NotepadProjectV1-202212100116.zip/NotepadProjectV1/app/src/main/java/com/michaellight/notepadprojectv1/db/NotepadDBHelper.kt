package com.michaellight.notepadprojectv1.db

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class NotepadDBHelper(context: Context) : SQLiteOpenHelper(
	context,
	NoteDBNameClass.DATABASE_NAME,
	null,
	NoteDBNameClass.DATABASE_VERSION
) {
	override fun onCreate(db: SQLiteDatabase?) {
		db?.execSQL(NoteDBNameClass.CREATE_TABLE)
	}

	override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
		db?.execSQL(NoteDBNameClass.DELETE_TABLE)
		onCreate(db)
	}
}