package com.michaellight.wishlistv1

class WishAdapter {
}