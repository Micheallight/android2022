package com.michaellight.wishlistv1

interface WishDAO {
}