package com.michaellight.wishlistv1

class MainViewModel {
}