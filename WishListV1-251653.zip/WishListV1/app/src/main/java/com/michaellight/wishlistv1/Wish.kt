package com.michaellight.wishlistv1

//class Wish {
//}
import android.content.ContentValues
import android.graphics.Bitmap
import android.os.Parcel
import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.*
import java.io.ByteArrayOutputStream
import com.google.auto.value.AutoValue;
import com.google.auto.value.AutoValue.CopyAnnotations
import java.sql.Date

@AutoValue
@Entity(tableName = "table_of_wishes")
data class Wish(
	@PrimaryKey
	val id: Int,

	val name: String,
	val date: String,
	var price: String,
	val photo: Bitmap?
) : Parcelable {
	constructor(parcel: Parcel) : this(
		parcel.readInt(),
		parcel.readString() ?: "",
		parcel.readString() ?: "",
		parcel.readString() ?: "",
		parcel.readParcelable(Bitmap::class.java.classLoader)
	) {
	}

	override fun writeToParcel(parcel: Parcel, flags: Int) {
		parcel.writeInt(id)
		parcel.writeString(name)
		parcel.writeString(date)
		parcel.writeString(price)
		parcel.writeParcelable(photo, flags)
	}

	override fun describeContents(): Int {
		return 0
	}

	companion object CREATOR : Parcelable.Creator<Wish> {
		override fun createFromParcel(parcel: Parcel): Wish {
			return Wish(parcel)
		}

		override fun newArray(size: Int): Array<Wish?> {
			return arrayOfNulls(size)
		}
	}

}