package com.michaellight.notepadprojectv2.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import java.util.ArrayList

class NotepadDBManager(val context: Context) {
	val notepadDBHelper = NotepadDBHelper(context)
	var db: SQLiteDatabase? = null

	fun openDB() {
		db = notepadDBHelper.writableDatabase
	}

	fun insertToDB(title: String, date: String, content: String) {
		val values = ContentValues().apply {
			put(NotepadDBNameClass.COLUMN_NAME_TITLE, title)
			put(NotepadDBNameClass.COLUMN_NAME_DATE, date)
			put(NotepadDBNameClass.COLUMN_NAME_TEXT, content)
		}
		db?.insert(NotepadDBNameClass.TABLE_NAME, null, values)
	}

	fun readDBData() : ArrayList<ListItem> {
		val dataList = ArrayList<ListItem>()
		val cursor = db?.query(
			NotepadDBNameClass.TABLE_NAME,
			null,
			null,
			null,
			null,
			null,
			null
		)

		while (cursor?.moveToNext()!!) {
			val dataTitle = cursor?.getString(cursor.getColumnIndexOrThrow(NotepadDBNameClass.COLUMN_NAME_TITLE))
			val dataDate = cursor?.getString(cursor.getColumnIndexOrThrow(NotepadDBNameClass.COLUMN_NAME_DATE))
			val dataText = cursor?.getString(cursor.getColumnIndexOrThrow(NotepadDBNameClass.COLUMN_NAME_TEXT))

			var item = ListItem()

			item.title = dataTitle
			item.date = dataDate
			item.text = dataText

			dataList.add(item)
		}

		cursor.close()
		return dataList
	}

	fun closeDB() {
		notepadDBHelper.close()
	}
}