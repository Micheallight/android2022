package com.michaellight.notepadprojectv2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.michaellight.notepadprojectv2.db.NotepadAdapter
import com.michaellight.notepadprojectv2.db.NotepadDBManager
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.edit_activity.*
import kotlinx.android.synthetic.main.edit_activity.view.*
import kotlinx.android.synthetic.main.rv_item.*
import kotlinx.android.synthetic.main.rv_item.view.*

class MainActivity : AppCompatActivity() {
	val notepadDBManager = NotepadDBManager(this)
	val notepadAdapter = NotepadAdapter(ArrayList(), this)

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)
		init()
	}

	override fun onResume() {
		super.onResume()
		notepadDBManager.openDB()
//		val dataList = notepadDBManager.readDBData()
		fillAdapter()
	}

	override fun onDestroy() {
		super.onDestroy()
		notepadDBManager.closeDB()
	}

	fun onClickAddNew(view: View) {
		var i = Intent(this, EditActivity::class.java)
		startActivity(i)
	}

	fun init() {
		rvMain.layoutManager = LinearLayoutManager(this)
		rvMain.adapter = notepadAdapter
	}

	fun fillAdapter() {
		val list = notepadDBManager.readDBData()
		notepadAdapter.updateAdapter(list)
		if (list.size > 0) {
			tvNoElements.visibility = View.GONE
		} else {
			tvNoElements.visibility = View.VISIBLE
		}
	}

	fun onClickDeleteItem(view: View) {
//		RecyclerView.ViewHolder.
		Log.d("TAG1", view.parent.toString())
	}
}