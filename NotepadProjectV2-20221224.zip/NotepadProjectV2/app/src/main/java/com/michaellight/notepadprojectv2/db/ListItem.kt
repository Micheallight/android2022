package com.michaellight.notepadprojectv2.db

class ListItem {
	var title = ""
	var date = ""
	var text = ""
}