package com.michaellight.notepadprojectv2.db

object NotepadIntentConstants {
	const val INTENT_TITLE_KEY = "title_ley"
	const val INTENT_DATE_KEY = "date_ley"
	const val INTENT_TEXT_KEY = "text_ley"
}