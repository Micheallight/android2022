package com.michaellight.wishlistv1.db

import android.content.Context
import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.michaellight.wishlistv1.CustomActivity
import com.michaellight.wishlistv1.R

class WishAdapter(listMain:ArrayList<ListItem>, contextMain: Context) : RecyclerView.Adapter<WishAdapter.NotepadHolder>() {
	var listArray = listMain
	var context = contextMain

	class NotepadHolder(itemView: View, contextView: Context) : RecyclerView.ViewHolder(itemView) {
		val itemTitle : TextView = itemView.findViewById(R.id.itemTitle)
		val itemDate : TextView = itemView.findViewById(R.id.itemDate)

		val context = contextView

		fun setData(item: ListItem) {
			itemTitle.text = item.name
			itemDate.text = item.date

			itemView.setOnClickListener {
				val intent = Intent(context, CustomActivity::class.java).apply {
					putExtra(WishIntentConstract.INTENT_ID_KEY, item.id)
					putExtra(WishIntentConstract.INTENT_NAME_KEY, item.name)
					putExtra(WishIntentConstract.INTENT_DATE_KEY, item.date)
					putExtra(WishIntentConstract.INTENT_PRICE_KEY, item.price)
				}
				context.startActivity(intent)
			}
		}
	}

	override fun getItemCount(): Int {
		return listArray.size
	}

	override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NotepadHolder {
		val inflater = LayoutInflater.from(parent.context)
		return NotepadHolder(inflater.inflate(R.layout.item_wish, parent, false), context)
	}

	override fun onBindViewHolder(holder: NotepadHolder, position: Int) {
		holder.setData(listArray.get(position))
	}

	fun updateAdapter(listItems: List<ListItem>) {
		listArray.clear()
		listArray.addAll(listItems)
		notifyDataSetChanged()
	}

	fun deleteItem(position: Int, dbManager: WishDBManager) {
		Log.d("", position.toString())
		Log.d("", listArray[position].id.toString())
		dbManager.deleteFromDB(listArray[position].id.toString())
		listArray.removeAt(position)
		notifyItemRangeChanged(0, listArray.size)
		notifyItemRemoved(position)
	}
}