package com.michaellight.wishlistv1.db

class ListItem {
	var id = 0
	var name = ""
	var date = ""
	var price = ""
	var image = 0
}