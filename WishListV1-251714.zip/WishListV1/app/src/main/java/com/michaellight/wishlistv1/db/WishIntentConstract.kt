package com.michaellight.wishlistv1.db

object WishIntentConstract {
	const val INTENT_ID_KEY = "id_key"
	const val INTENT_NAME_KEY = "name_key"
	const val INTENT_DATE_KEY = "date_key"
	const val INTENT_PRICE_KEY = "price_key"
	const val INTENT_IMAGE_KEY = "image_key"
}