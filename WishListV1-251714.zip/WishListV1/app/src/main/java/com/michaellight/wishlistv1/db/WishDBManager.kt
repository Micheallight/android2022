package com.michaellight.wishlistv1.db

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.provider.BaseColumns
import java.util.ArrayList

class WishDBManager(val context: Context) {
	val wishDBHelper = WishDBHelper(context)
	var db: SQLiteDatabase? = null

	fun openDB() {
		db = wishDBHelper.writableDatabase
	}

	fun insertToDB(title: String, date: String, content: String) {
		val values = ContentValues().apply {
			put(WishDBNameClass.COLUMN_NAME_NAME, title)
			put(WishDBNameClass.COLUMN_NAME_DATE, date)
			put(WishDBNameClass.COLUMN_NAME_PRICE, content)
		}
		db?.insert(WishDBNameClass.TABLE_NAME, null, values)
	}

	fun updateItemInDB(title: String, date: String, content: String, id: Int) {
		val selection = BaseColumns._ID + "=" + id
		val values = ContentValues().apply {
			put(WishDBNameClass.COLUMN_NAME_NAME, title)
			put(WishDBNameClass.COLUMN_NAME_DATE, date)
			put(WishDBNameClass.COLUMN_NAME_PRICE, content)
		}
		db?.update(WishDBNameClass.TABLE_NAME, values, selection, null)
	}

	fun deleteFromDB(id: String) {
		val selection = BaseColumns._ID + "=" + id
		db?.delete(WishDBNameClass.TABLE_NAME, selection, null)
	}

	fun readDBData(searchText: String) : ArrayList<ListItem> {
		val dataList = ArrayList<ListItem>()
		val selection = "${WishDBNameClass.COLUMN_NAME_NAME} LIKE ? ORDER BY ${WishDBNameClass.COLUMN_NAME_DATE} DESC"
		val cursor = db?.query(
			WishDBNameClass.TABLE_NAME,
			null,
			selection,
			arrayOf("%$searchText%"),
			null,
			null,
			null
		)

		while (cursor?.moveToNext()!!) {
			val dataID = cursor?.getInt(cursor.getColumnIndexOrThrow(BaseColumns._ID))
			val dataName = cursor?.getString(cursor.getColumnIndexOrThrow(WishDBNameClass.COLUMN_NAME_NAME))
			val dataDate = cursor?.getString(cursor.getColumnIndexOrThrow(WishDBNameClass.COLUMN_NAME_DATE))
			val dataPrice = cursor?.getString(cursor.getColumnIndexOrThrow(WishDBNameClass.COLUMN_NAME_PRICE))

			var item = ListItem()

			item.id = dataID
			item.name = dataName
			item.date = dataDate
			item.price = dataPrice

			dataList.add(item)
		}

		cursor.close()
		return dataList
	}

	fun closeDB() {
		wishDBHelper.close()
	}
}